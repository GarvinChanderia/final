import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

dataset = pd.read_csv("csv_data.csv")

dataset.head(10)

dataset.tail(10)

len(dataset)

dataset.info()

from sklearn.preprocessing import LabelEncoder
labelEncoder = LabelEncoder()

dataset2 = dataset.drop(["S.No.", "Total Rooms"], axis = 1)

dataset_copy = dataset

cols = dataset2.columns

for x in cols:
  dataset_copy[x] = labelEncoder.fit_transform(dataset_copy[x])

dataset_copy.head()

sns.scatterplot( x ="City" , y = "Total Rooms", data = dataset_copy)

sns.boxplot( x  = "Total Rooms", data = dataset_copy)

