#!/usr/bin/env python
# coding: utf-8

# In[71]:


import pandas as pd 
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import statistics
from scipy.stats import norm


# In[72]:


glaxo_dataset = pd.read_csv('./GLAXO.csv')
glaxo_dataset.head(10)


# In[73]:


glaxo_dataset.shape


# In[74]:


glaxo_dataset.info()


# In[75]:


glaxo_dataset.corr(numeric_only = True)


# In[76]:


sns.pairplot(glaxo_dataset)


# In[77]:


glaxo_dataset.columns


# In[78]:


glaxo_dataset2 = glaxo_dataset.drop('Date', axis =1)
glaxo_dataset2.head()


# In[79]:


from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaled_dataset = scaler.fit_transform(glaxo_dataset2)
print(type(scaled_dataset))
scaled_dataset


# In[80]:


from sklearn.cluster import KMeans
wcss = []
for i in range(1, 10):
    kmeans = KMeans(n_clusters=i,random_state=0,n_init = 10)
    kmeans.fit(scaled_dataset)
    wcss.append(kmeans.inertia_)


# In[81]:


plt.plot(range(1, 10), wcss)
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()


# In[103]:


#Clustering the data
Glaxo_clusters_2 = KMeans(2, random_state=40, n_init = 10)
Glaxo_clusters_2.fit(scaled_dataset)


# In[83]:


Glaxo_clusters_2.labels_


# In[84]:


glaxo_dataset_2 = glaxo_dataset 


# In[85]:


glaxo_dataset_2['new_cluster_id2'] = Glaxo_clusters_2.labels_


# In[86]:


glaxo_dataset.iloc[40:50]


# In[87]:


glaxo_dataset['new_cluster_id2'].unique()


# In[88]:


Glaxo_clusters_3 = KMeans(3, random_state=40)
Glaxo_clusters_3.fit(scaled_dataset)


# In[89]:


Glaxo_clusters_3.labels_


# In[90]:


glaxo_dataset_3 = glaxo_dataset


# In[91]:


glaxo_dataset_3['new_cluster_id3'] = Glaxo_clusters_3.labels_


# In[92]:


glaxo_dataset_3.head()


# In[93]:


Glaxo_clusters_5 = KMeans(5, random_state=40)
Glaxo_clusters_5.fit(scaled_dataset)


# In[94]:


Glaxo_clusters_3.labels_


# In[95]:


glaxo_dataset_5 = glaxo_dataset


# In[96]:


glaxo_dataset_5['new_cluster_id5'] = Glaxo_clusters_5.labels_


# In[97]:


glaxo_dataset_5['new_cluster_id5'].unique()


# In[98]:


glaxo_dataset_3.head()


# <h3> Plotting the clusters <h3>

# In[99]:


plt.figure(figsize=(8,8))
sns.scatterplot(x= "Close", y = "Turnover (Lacs)", hue = 'new_cluster_id2', data = glaxo_dataset_2, palette = 'Set2')
plt.show()


# In[100]:


plt.figure(figsize=(8,8))
sns.scatterplot(x= "Close", y = "Turnover (Lacs)", hue = 'new_cluster_id3', 
data = glaxo_dataset_3, palette = 'Set2')
plt.show()


# In[101]:


plt.figure(figsize=(8,8))
sns.scatterplot(x= "Close", y = "Turnover (Lacs)", hue = 'new_cluster_id5', 
data = glaxo_dataset_5, palette = 'Set2')

