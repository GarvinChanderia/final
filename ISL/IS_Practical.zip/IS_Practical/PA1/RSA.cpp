//This code words for small no.s only (p or q should be single digits)
#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
class RSA
{
private:
    int p, q, e, d, n, Phi_n;
    unsigned long long C, P;
    int plain;

public:
    RSA()
    {
        cout << "Enter two prime numbers : " << endl;
        cin >> p >> q;
        n = p * q;
        Phi_n = (p - 1) * (q - 1);
    }

    void choosePublicKey()
    {
        cout<<"Enter the public key value: ";
        cin >> e;
        while ((gcd(Phi_n, e)) != 1)
        {
            cout << "Bad public key. Enter again." << endl;
            cin >> e;
        }
    }

    int gcd(int a, int b)
    {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }

    void generatePrivateKey()
    {
        int k = 0;
        int expr = 1 + (k * Phi_n);

        while ((expr % e) != 0)
        {
            k++;
            expr = 1 + (k * Phi_n);
        }
        d = expr / e;
    }
    void showPrivateKey()
    {
        cout << "The private key generated is : " << d << endl;
    }

    void Encrypt()
    {
        cout << "Enter the message : " << endl;
        cin >> plain;
        
        C = (unsigned long long)pow(plain, e) % n;

        cout << "The encypted value is : " << C << endl;
    }

    void Decrypt()
    {
        P = (unsigned long long)pow(C, d) % n;

        cout << "The decrypted value is : " << P;
    }
};

int main()
{
    RSA R;
    R.choosePublicKey();
    R.generatePrivateKey();
    R.showPrivateKey();
    R.Encrypt();
    R.Decrypt();
  

    return 0;
}