# This code works for big numbers (p and q can be double digit no.s)
import math

class RSA:
    def __init__(self):
        self.p = int(input("Enter a prime number: "))
        self.q = int(input("Enter another prime number: "))
        self.n = self.p * self.q
        self.Phi_n = (self.p - 1) * (self.q - 1)
        self.d =0;
        self.e = int(input("Enter the public key value: "))
        while math.gcd(self.Phi_n, self.e) != 1:
            self.e = int(input("Bad public key. Enter again: "))
        self.d = 0;

    def generatePrivateKey(self):
        k =0
        expr = 1 + (k * self.Phi_n)
        while ((expr % self.e) != 0):
            # print(k)
            k = k+1
            expr = 1 + (k * self.Phi_n)
        self.d = int(expr / self.e)

    def showPrivateKey(self):
        print("The private key is : " , self.d)


    def encrypt(self, input):
        cipher_text = pow(input, self.e) % self.n
        return cipher_text

    def decrypt(self, cipher_text):
        plain_text = pow(cipher_text, self.d) % self.n
        return plain_text

def main():
    R = RSA()
    message = int(input("Enter the message: "))
    cipher_text = R.encrypt(message)
    R.generatePrivateKey()
    R.showPrivateKey()
    print("The encrypted text is: ", cipher_text)
    plain_text = R.decrypt(cipher_text)
    print("The decrypted text is: ", plain_text)


if __name__ == "__main__":
    main()
