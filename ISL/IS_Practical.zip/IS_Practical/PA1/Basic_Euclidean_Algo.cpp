#include <iostream>
using namespace std;

int gcd(int a, int b)
{
    if (a == 0)
        return b;
    return gcd(b % a, a);
}
 
// Driver Code
int main()
{
    int a, b;
    cout<< "Enter the first number : "<<endl;
    cin>> a;
    cout<< "Enter the second number : "<<endl;
    cin>> b;
    cout<<gcd(a,b);
 
    return 0;
}