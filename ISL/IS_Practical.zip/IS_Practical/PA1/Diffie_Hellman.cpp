#include <iostream>
#include <unordered_map>
#include <math.h>
using namespace std;

class Diffie_Hellman
{
private:
    int p, a, Xa, Xb, Ya, Yb, ka, kb;
    int k;    // k is a temp variable
public:
    Diffie_Hellman()
    {
        cout << "Enter a big prime number : ";
        cin >> p;
        cout << endl;
    }

    void getting_a()
    {
        unordered_map<int, int> primitive_root;
        for (a = 1; a < p; a++)
        {

            for (int i = 1; i < p - 1; i++)
            {

                int k = pow(a, i);
                primitive_root[k % p] = i;
            }

            if (primitive_root.size() == (p - 1))
            {
                break;
            }
        }
    }

    void getPrivateKeys()
    {
        cout << "Enter the private key value for A: " << endl;
        cin >> Xa;
        cout << "Enter the private key value for B: " << endl;
        cin >> Xb;
    }

    void calculatePublicKeys()
    {
        k = (int)pow(a, Xa);
        Ya = k % p;

        k = (int)pow(a, Xb);
        Yb = k % p;
    }
    void generated_SecretKey()
    {
        k = (int)pow(Yb, Xa);
        ka = k % p;

        k = (int)pow(Ya, Xb);
        kb = k % p;
    }

    void print()
    {
        cout << "a : " << a << endl;
        cout << "Prime no. : " << p << endl;
        cout << "Public key of A : " << Ya << endl;
        cout << "Public key of B : " << Yb << endl;
        cout<<"The generated secret keys for A and B are : "<<ka<<", "<<kb<<endl;
    }
};

int main()
{
    Diffie_Hellman obj;
    obj.getting_a();
    obj.getPrivateKeys();
    obj.calculatePublicKeys();
    obj.generated_SecretKey();
    obj.print();

    return 0;
}