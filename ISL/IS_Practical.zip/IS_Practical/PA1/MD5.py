# Python 3 code to demonstrate the 
# working of MD5 (string - hexadecimal)

import hashlib

# initializing string
str2hash = "Ambush at 0900"

result = hashlib.md5(str2hash.encode())

print("The hexadecimal equivalent of hash is : ", end ="")
print(result.hexdigest())
