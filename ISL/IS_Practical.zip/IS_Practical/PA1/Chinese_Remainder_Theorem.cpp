#include <iostream>
#include <vector>
using namespace std;

int findX(vector <int> a, vector <int> m, int n)
{
    int M = 1, X = 0, temp = 0;
    int Mi[n], Mi_inverse[n];

    // Calculating M
    for (int i = 0; i < n; i++)
    {
        M = M * m[i];
    }
    cout <<"M = "<< M << endl;
    // Calculating Mi
    for (int i = 0; i < n; i++)
    {
        Mi[i] = M / m[i];
    }
    //Printing Mi
    cout<<"Mi values are : ";
    for (int i = 0; i < n; i++)
    {
        cout << Mi[i] << " ";
    }
    cout << endl;
    // Calculating Mi_inverse
    for (int i = 0; i < n; i++)
    {
        int z = 1;
        int x = Mi[i];
        while ((z * x) % m[i] != 1)
        {
            z++;
        }
        Mi_inverse[i] = z;
    }
    cout<<"Mi_inverse values are : ";
    for (int i = 0; i < n; i++)
    {
        cout << Mi_inverse[i] << " ";
    }
    cout << endl;

    // Calculating X
    for (int i = 0; i < n; i++)
    {
        int j =(a[i] * Mi_inverse[i] * Mi[i]);
        temp += j;
    
    }

    // Final answer
    X = temp % M;
    return X;
}

int main()
{
    // int a[] = {2, 3, 10};
    // int m[] = {5, 7, 11};
    int n, input;
    cout<<"Enter the number of equations : ";
    cin>>n;
    vector <int> a;
    cout<<"Enter the values of a "<<endl;
    for(int i =0; i<n; i++){
        cin>> input;
        a.push_back(input);
    }
    vector <int> m;
    cout<<"Enter the values of m "<<endl;
     for(int i =0; i<n; i++){
        cin>> input;
        m.push_back(input);
    }
    int X = findX(a, m, n);
    cout << "The answer using CRT is: " << X << endl;
    return 0;
}