#include <iostream>
using namespace std;

class Euclidean
{
public:
    int a, b, q, r, t1 = 0, t2 = 1, t = 0, s1 = 1, s2 = 0, s = 0, a1, b1;

    void input()
    {
        cout << "Enter the value of a and b" << endl;
        cin >> a >> b;
        if (b > a)
            swap(a, b);
        a1 = a;
        b1 = b;
    }

    void EAlgo()
    {
        while (r > 0)
        {
            q = a / b;
            r = a % b;
            t = t1 - (t2 * q);
            s = s1 - (s2 * q);
            a = b;
            b = r;
            t1 = t2;
            t2 = t;
            s1 = s2;
            s2 = s;
        }
    }

    void display()
    {
        cout << "The value of x is: " << s1 << endl;
        cout << "The value of y is: " << t1 << endl;

        int gcd = 0;
        gcd = a1 * s1 + b1 * t1;
        cout << "The GCD is: " << gcd << endl;
    }
};

int main()
{

    Euclidean e;
    e.input();
    e.EAlgo();
    e.display();

    return 0;
}