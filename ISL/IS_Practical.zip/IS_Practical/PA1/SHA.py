# Python 3 code to demonstrate 
# SHA hash algorithms. 

import hashlib 

# initializing string 
str = "Attack at 1630"
# encoding the string using encode() 

result = hashlib.sha1(str.encode()) 

# printing the equivalent hexadecimal value. 
print("The hexadecimal equivalent of SHA1 is : " , result.hexdigest()) 


